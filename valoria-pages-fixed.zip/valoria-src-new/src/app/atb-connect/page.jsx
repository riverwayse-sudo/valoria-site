import Nav from '@/components/Nav'
import Footer from '@/components/Footer'
import Reveal from '@/components/Reveal'
import { COLORS } from '@/lib/brand'
import '../pages.css'

export const metadata = {
  title: 'ATB Connect — Search Assessed African Talent',
  description: 'Search pre-assessed candidates by VALU Index score, cluster strength, sector, and designation. Hire with intelligence, not with hope.',
}

const color = COLORS.blue

export default function AtbConnectPage() {
  return (
    <>
      <Nav />
      <main id="main-content">
        <section className="page-hero">
          <div className="page-hero-inner">
            <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text" style={{ color }}>01 &nbsp;&middot;&nbsp; FOR EMPLOYERS</span></div>
            <h1 className="page-title">Hire on evidence,<br /><em>not on instinct.</em></h1>
            <p className="page-sub">
              ATB Connect is the candidate modality of the Valoria marketplace. Every professional you search has already been through the VALU Index — so you&apos;re comparing assessed capability, not curated résumés.
            </p>
            <div className="page-hero-actions">
              <a href="https://assessment.valoriainstitute.com/" className="btn-gold" target="_blank" rel="noopener noreferrer">SEARCH TALENT</a>
              <a href="/prime" className="btn-outline">SEE THE PRIME FRAMEWORK</a>
            </div>
          </div>
        </section>

        <section className="page-section">
          <div className="page-section-inner two-col">
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">THE PROBLEM WITH CVS</span></div>
              <h2 className="section-title">The CV tells you<br />what someone <em>claims.</em></h2>
              <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '15px' }}>
                The VALU Index tells you what they can actually do across five capability clusters. Every profile on ATB Connect carries a live score, a tier designation, and a cluster breakdown — so shortlisting starts from evidence instead of a polished résumé.
              </p>
            </Reveal>
            <Reveal>
              <ul className="checklist" role="list">
                {[
                  'Filter by VALU Index score, cluster strength, sector, and tier designation',
                  'Every candidate independently assessed — no self-reported skill claims',
                  'Compare candidates on the same five-cluster standard, side by side',
                  'Reach out directly once a profile matches your role',
                ].map((t, i) => (
                  <li key={i}>
                    <span className="dot"><svg width="9" height="9" viewBox="0 0 9 9" fill="none"><path d="M1.5 4.5l2 2 4-4" stroke={color} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" /></svg></span>
                    {t}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </section>

        <section className="page-section alt">
          <div className="page-section-inner">
            <Reveal>
              <div className="eyebrow" style={{ justifyContent: 'center' }}><div className="eyebrow-line" /><span className="eyebrow-text">HOW ATB CONNECT WORKS</span><div className="eyebrow-line" /></div>
              <h2 className="section-title" style={{ textAlign: 'center', marginBottom: '48px' }}>Three steps to your<br /><em>next precision hire.</em></h2>
            </Reveal>
            <div className="three-col">
              {[
                { num: '01', title: 'Create an employer account', body: 'Set up your organisation profile on the Valoria assessment platform. Free to search, no subscription required to browse.' },
                { num: '02', title: 'Search by what matters', body: 'Filter candidates by VALU Index score, PRIME cluster strength, sector, designation tier, and location. Compare on the same standard.' },
                { num: '03', title: 'Reach out directly', body: 'Once a profile matches your role requirements, contact the candidate directly through the platform. No agency in the middle.' },
              ].map((step) => (
                <Reveal key={step.num}>
                  <div className="card-gold">
                    <div style={{ fontSize: '32px', fontWeight: 200, color, marginBottom: '16px' }}>{step.num}</div>
                    <h3 style={{ color: 'var(--parchment)', fontSize: '16px', fontWeight: 500, marginBottom: '12px' }}>{step.title}</h3>
                    <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '14px' }}>{step.body}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        <section className="page-section">
          <div className="page-section-inner two-col">
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">THE TIER SYSTEM</span></div>
              <h2 className="section-title">Merit made<br /><em>visible at a glance.</em></h2>
              <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '15px' }}>
                Every candidate on ATB Connect carries a tier designation — Emerging, Established, or Elite — earned through verified activity, not purchased through a subscription. The tier is a credential, not a badge.
              </p>
            </Reveal>
            <Reveal>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                {[
                  { tier: '✦ Emerging', desc: 'Entry-level verified professional. Building platform with institutional backing.', bg: 'var(--dark-card)', border: '#D4C9A8' },
                  { tier: '✦✦ Established', desc: 'Actively verified mid-level professional with demonstrated track record.', bg: 'var(--dark-mid)', border: 'var(--gold)' },
                  { tier: '✦✦✦ Elite', desc: 'Benchmark of excellence. Sustained history across multiple engagements.', bg: 'var(--gold)', border: 'var(--gold)', dark: true },
                ].map((t) => (
                  <div key={t.tier} style={{
                    padding: '16px 20px', borderRadius: '8px',
                    background: t.bg, border: `1px solid ${t.border}44`,
                  }}>
                    <div style={{ fontWeight: 700, fontSize: '14px', color: t.dark ? 'var(--dark)' : 'var(--gold)', marginBottom: '4px' }}>{t.tier}</div>
                    <div style={{ fontSize: '13px', fontWeight: 300, color: t.dark ? 'var(--dark-mid)' : 'var(--dim)' }}>{t.desc}</div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </section>

        <section className="page-section alt cta-banner">
          <Reveal>
            <div className="eyebrow" style={{ justifyContent: 'center' }}><div className="eyebrow-line" /><span className="eyebrow-text">FOR EMPLOYERS</span><div className="eyebrow-line" /></div>
            <h2 className="section-title">Start searching<br /><em>assessed talent.</em></h2>
            <p className="page-sub">ATB Connect is live. Create an employer account to start filtering candidates by the standard that actually matters.</p>
            <a href="https://assessment.valoriainstitute.com/" className="btn-gold" target="_blank" rel="noopener noreferrer">SEARCH TALENT</a>
          </Reveal>
        </section>
      </main>
      <Footer />
    </>
  )
}
