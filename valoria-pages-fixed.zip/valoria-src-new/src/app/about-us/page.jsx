import Nav from '@/components/Nav'
import Footer from '@/components/Footer'
import Reveal from '@/components/Reveal'
import '../pages.css'

export const metadata = {
  title: 'About Valoria Institute',
  description: 'Valoria Institute builds the infrastructure that transforms African professional talent from overlooked potential into undeniable excellence.',
}

export default function AboutPage() {
  return (
    <>
      <Nav />
      <main id="main-content">
        <section className="page-hero">
          <div className="page-hero-inner">
            <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">ABOUT VALORIA INSTITUTE</span></div>
            <h1 className="page-title">Talent is not<br /><em>the problem.</em></h1>
            <p className="page-sub">
              Infrastructure is. Valoria Institute builds the systems that let African professionals prove what they can do — and let the people hiring, booking, and developing them see it clearly.
            </p>
          </div>
        </section>

        <section className="page-section">
          <div className="page-section-inner two-col">
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">THE FOUNDING CONVICTION</span></div>
              <h2 className="section-title">Named after a<br /><em>principle, not a feature.</em></h2>
              <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '15px' }}>
                The name Valoria is rooted in the Spanish and Latin <em>valor</em> — meaning worth, courage, and value. This institution is not named after what it does. It is named after what it believes: that every professional has inherent worth deserving to be seen, grown, and matched to opportunity with precision.
              </p>
            </Reveal>
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">THE FOUNDING STATEMENT</span></div>
              <blockquote style={{
                borderLeft: '2px solid var(--gold)', paddingLeft: '24px',
                color: 'var(--parchment)', fontWeight: 300, lineHeight: 1.8,
                fontSize: '15px', fontStyle: 'italic'
              }}>
                &ldquo;Valoria Institute builds the infrastructure that transforms African professional talent from overlooked potential into undeniable excellence — developing careers with architecture, sourcing talent with precision, and giving every voice the platform it has earned.&rdquo;
              </blockquote>
              <p style={{ color: 'var(--dim)', fontSize: '12px', marginTop: '16px', letterSpacing: '.1em' }}>
                TEMITAYO · FOUNDER &amp; DIRECTOR · MARCH 2024
              </p>
            </Reveal>
          </div>
        </section>

        <section className="page-section alt">
          <div className="page-section-inner">
            <Reveal>
              <div className="eyebrow" style={{ justifyContent: 'center' }}><div className="eyebrow-line" /><span className="eyebrow-text">VISION · MISSION · PURPOSE</span><div className="eyebrow-line" /></div>
            </Reveal>
            <div className="three-col" style={{ marginTop: '40px' }}>
              {[
                { label: 'VISION', title: 'An Africa where professional merit always finds its platform.', body: 'Where careers are built with architecture, not shaped by chance. Where businesses make their most important hires with confidence and clarity.' },
                { label: 'MISSION', title: 'To build and operate Africa\'s premier human capital institution.', body: 'One that develops professionals with rigour, surfaces talent with merit, and enables precision hiring through a technology ecosystem designed for the seriousness the African professional market has always deserved.' },
                { label: 'PURPOSE', title: 'To bridge the gap between latent brilliance and institutional scale.', body: 'We exist because talent is not the problem. Infrastructure is. For every professional whose career has stalled not for lack of ability, but lack of access — Valoria Institute is the answer.' },
              ].map((item) => (
                <Reveal key={item.label}>
                  <div className="card-gold" style={{ height: '100%' }}>
                    <div className="eyebrow" style={{ marginBottom: '16px' }}><span className="eyebrow-text">{item.label}</span></div>
                    <h3 style={{ color: 'var(--gold)', fontSize: '18px', fontWeight: 300, lineHeight: 1.5, marginBottom: '16px' }}>{item.title}</h3>
                    <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '14px' }}>{item.body}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        <section className="page-section">
          <div className="page-section-inner two-col">
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">WHAT WE ARE</span></div>
              <h2 className="section-title">An institution.<br /><em>Not a platform.</em></h2>
              <ul className="checklist" role="list">
                {[
                  'Infrastructure for African talent',
                  'Development-first, always',
                  'A merit-based standard',
                  'Proudly African, globally ambitious',
                  'A system professionals rise within',
                ].map((t, i) => (
                  <li key={i}>
                    <span className="dot"><svg width="9" height="9" viewBox="0 0 9 9" fill="none"><path d="M1.5 4.5l2 2 4-4" stroke="var(--gold)" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" /></svg></span>
                    {t}
                  </li>
                ))}
              </ul>
            </Reveal>
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">WHAT WE ARE NOT</span></div>
              <h2 className="section-title">Not a job board.<br /><em>Not a LinkedIn.</em></h2>
              <ul className="checklist" role="list" style={{ opacity: 0.6 }}>
                {[
                  'A job board',
                  'A speaker booking agency',
                  'A neutral marketplace',
                  'A LinkedIn alternative',
                  'A platform you use once',
                ].map((t, i) => (
                  <li key={i} style={{ textDecoration: 'line-through', opacity: 0.7 }}>
                    <span className="dot" style={{ textDecoration: 'none' }}>✗</span>
                    {t}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </section>

        <section className="page-section alt cta-banner">
          <Reveal>
            <div className="eyebrow" style={{ justifyContent: 'center' }}><div className="eyebrow-line" /><span className="eyebrow-text">WORTH. BUILT.</span><div className="eyebrow-line" /></div>
            <h2 className="section-title">Ready to see<br /><em>where you stand?</em></h2>
            <p className="page-sub">Take the VALU Index — free, and valid for 12 months.</p>
            <a href="https://assessment.valoriainstitute.com/" className="btn-gold" target="_blank" rel="noopener noreferrer">BEGIN THE VALU INDEX</a>
          </Reveal>
        </section>
      </main>
      <Footer />
    </>
  )
}
