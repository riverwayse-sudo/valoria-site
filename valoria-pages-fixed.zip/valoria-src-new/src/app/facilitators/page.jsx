import Nav from '@/components/Nav'
import Footer from '@/components/Footer'
import Reveal from '@/components/Reveal'
import { COLORS } from '@/lib/brand'
import '../pages.css'

export const metadata = {
  title: 'Commission Facilitators — Valoria Develop',
  description: 'Commission PRIME-certified facilitators to run development programmes for your teams. PRIME is the capability architecture — Valoria-certified facilitators are its delivery engine.',
}

const color = COLORS.teal

export default function FacilitatorsPage() {
  return (
    <>
      <Nav />
      <main id="main-content">
        <section className="page-hero">
          <div className="page-hero-inner">
            <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text" style={{ color }}>03 &nbsp;&middot;&nbsp; FOR TRAINING BUYERS</span></div>
            <h1 className="page-title">Don&apos;t train on theory.<br /><em>Train on the framework.</em></h1>
            <p className="page-sub">
              Valoria Develop is the facilitator modality of the marketplace. Commission PRIME-certified facilitators to run development programmes for your teams — built directly on the same five-cluster standard the VALU Index measures against.
            </p>
            <div className="page-hero-actions">
              <a href="https://assessment.valoriainstitute.com/" className="btn-gold" target="_blank" rel="noopener noreferrer">COMMISSION FACILITATORS</a>
              <a href="/prime" className="btn-outline">SEE THE PRIME FRAMEWORK</a>
            </div>
          </div>
        </section>

        <section className="page-section">
          <div className="page-section-inner two-col">
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">THE TRAINING PROBLEM</span></div>
              <h2 className="section-title">Generic training closes<br /><em>the wrong gaps.</em></h2>
              <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '15px' }}>
                Most corporate training runs on generic content, disconnected from how anyone is actually measured afterward. Valoria-certified facilitators teach to the same five PRIME clusters your team&apos;s VALU Index scores them on — so development closes the exact gaps the assessment surfaced.
              </p>
            </Reveal>
            <Reveal>
              <ul className="checklist" role="list">
                {[
                  'Facilitators certified directly against the PRIME framework',
                  'Programmes mapped to the same five clusters as the VALU Index',
                  'Commission for a single team or a full cohort',
                  'Track movement on the same standard before and after the programme',
                ].map((t, i) => (
                  <li key={i}>
                    <span className="dot"><svg width="9" height="9" viewBox="0 0 9 9" fill="none"><path d="M1.5 4.5l2 2 4-4" stroke={color} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" /></svg></span>
                    {t}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </section>

        <section className="page-section alt">
          <div className="page-section-inner">
            <Reveal>
              <div className="eyebrow" style={{ justifyContent: 'center' }}><div className="eyebrow-line" /><span className="eyebrow-text">HOW IT WORKS</span><div className="eyebrow-line" /></div>
              <h2 className="section-title" style={{ textAlign: 'center', marginBottom: '48px' }}>Assessment-aligned<br /><em>development in three steps.</em></h2>
            </Reveal>
            <div className="three-col">
              {[
                { num: '01', title: 'Assess your team first', body: 'Run your team through the VALU Index to identify which PRIME clusters need the most development. The data tells you where to invest.' },
                { num: '02', title: 'Commission the right programme', body: 'Browse certified facilitators by the cluster they teach. Commission a programme designed specifically for the gaps your team showed.' },
                { num: '03', title: 'Measure the movement', body: 'Re-assess your team on the same VALU Index after the programme. The improvement is measurable against the same standard — not just a participant satisfaction score.' },
              ].map((step) => (
                <Reveal key={step.num}>
                  <div className="card-gold">
                    <div style={{ fontSize: '32px', fontWeight: 200, color, marginBottom: '16px' }}>{step.num}</div>
                    <h3 style={{ color: 'var(--parchment)', fontSize: '16px', fontWeight: 500, marginBottom: '12px' }}>{step.title}</h3>
                    <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '14px' }}>{step.body}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        <section className="page-section">
          <div className="page-section-inner two-col">
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">FOR FACILITATORS</span></div>
              <h2 className="section-title">Get certified.<br /><em>Get commissioned.</em></h2>
              <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '15px' }}>
                If you&apos;re a trainer or facilitator, PRIME certification puts you in front of every training buyer searching Valoria Develop for programmes mapped to the framework. The certification starts with your own VALU Index assessment.
              </p>
              <a href="/develop" className="btn-gold" style={{ marginTop: '24px', display: 'inline-block' }}>BECOME A CERTIFIED FACILITATOR</a>
            </Reveal>
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">CERTIFICATION PATH</span></div>
              <ul className="checklist" role="list">
                {[
                  'Take the VALU Index to establish your own baseline across all five clusters',
                  'Complete facilitator certification on the cluster(s) you want to teach',
                  'Get listed on Valoria Develop, searchable by training buyers',
                  'Receive commissions directly through the platform',
                ].map((t, i) => (
                  <li key={i}>
                    <span className="dot"><svg width="9" height="9" viewBox="0 0 9 9" fill="none"><path d="M1.5 4.5l2 2 4-4" stroke={color} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" /></svg></span>
                    {t}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </section>

        <section className="page-section alt cta-banner">
          <Reveal>
            <div className="eyebrow" style={{ justifyContent: 'center' }}><div className="eyebrow-line" /><span className="eyebrow-text">FOR TRAINING BUYERS</span><div className="eyebrow-line" /></div>
            <h2 className="section-title">Develop your team<br /><em>against the standard.</em></h2>
            <p className="page-sub">Valoria Develop is live. Create an account to start browsing certified facilitators and commissioning programmes.</p>
            <a href="https://assessment.valoriainstitute.com/" className="btn-gold" target="_blank" rel="noopener noreferrer">COMMISSION FACILITATORS</a>
          </Reveal>
        </section>
      </main>
      <Footer />
    </>
  )
}
