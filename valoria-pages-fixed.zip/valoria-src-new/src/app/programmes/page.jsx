import Nav from '@/components/Nav'
import Footer from '@/components/Footer'
import Reveal from '@/components/Reveal'
import { PRIME_CLUSTERS } from '@/lib/brand'
import '../pages.css'

export const metadata = {
  title: 'Programmes — Valoria Develop',
  description: 'Development programmes mapped to the PRIME framework, delivered by certified facilitators through Valoria Develop.',
}

export default function ProgrammesPage() {
  return (
    <>
      <Nav />
      <main id="main-content">
        <section className="page-hero">
          <div className="page-hero-inner">
            <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">PROGRAMMES</span></div>
            <h1 className="page-title">A programme<br />for every <em>cluster.</em></h1>
            <p className="page-sub">
              Every Valoria Develop programme is built against one or more PRIME clusters, so a team&apos;s development maps directly onto how they&apos;ll be measured. No generic content. No misaligned training.
            </p>
          </div>
        </section>

        <section className="page-section">
          <div className="page-section-inner two-col">
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">WHY MAPPED PROGRAMMES WORK</span></div>
              <h2 className="section-title">Development that<br /><em>closes real gaps.</em></h2>
              <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '15px' }}>
                When you know exactly which cluster a team scores lowest on, you commission the programme that addresses that cluster. The same PRIME standard that measures them is what the facilitator teaches to — so improvement is visible on re-assessment, not just in a post-training survey.
              </p>
            </Reveal>
            <Reveal>
              <ul className="checklist" role="list">
                {[
                  'Programmes built on the same five clusters as the VALU Index',
                  'Delivered by facilitators certified against the PRIME framework',
                  'Commission for individuals, teams, or full cohorts',
                  'Re-assess on the same standard to measure actual movement',
                ].map((t, i) => (
                  <li key={i}>
                    <span className="dot"><svg width="9" height="9" viewBox="0 0 9 9" fill="none"><path d="M1.5 4.5l2 2 4-4" stroke="var(--gold)" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" /></svg></span>
                    {t}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </section>

        <section className="page-section alt">
          <div className="page-section-inner">
            <Reveal>
              <div className="eyebrow" style={{ justifyContent: 'center' }}><div className="eyebrow-line" /><span className="eyebrow-text">THE FIVE PRIME PROGRAMMES</span><div className="eyebrow-line" /></div>
              <h2 className="section-title" style={{ textAlign: 'center', marginBottom: '48px' }}>One for every<br /><em>capability cluster.</em></h2>
            </Reveal>
            <div className="two-col" style={{ gap: '20px' }}>
              {PRIME_CLUSTERS.map((c) => (
                <Reveal key={c.letter}>
                  <div className="card-gold">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '16px' }}>
                      <div className="cluster-letter" style={{ color: c.color, fontSize: '28px', fontWeight: 200 }}>{c.letter}</div>
                      <div className="cluster-name" style={{ color: 'var(--parchment)' }}>{c.name} Programme</div>
                    </div>
                    <p className="cluster-desc">A facilitator-led programme building the {c.name.toLowerCase()} cluster. Delivered by PRIME-certified facilitators and benchmarked against the VALU Index before and after delivery.</p>
                    <div style={{ marginTop: '16px', fontSize: '11px', fontWeight: 600, letterSpacing: '.12em', color: c.color }}>PRIME CLUSTER · {c.letter}</div>
                  </div>
                </Reveal>
              ))}
            </div>
            <p style={{ color: 'var(--faint)', fontSize: '12px', marginTop: '32px', textAlign: 'center' }}>
              Full programme outlines and durations confirmed at commissioning. Contact us for a tailored proposal.
            </p>
          </div>
        </section>

        <section className="page-section cta-banner">
          <Reveal>
            <h2 className="section-title">Commission a<br /><em>programme.</em></h2>
            <p className="page-sub">Tell us which cluster your team needs to close, and we&apos;ll match you with a certified facilitator.</p>
            <a href="/contact-us" className="btn-gold">CONTACT US</a>
          </Reveal>
        </section>
      </main>
      <Footer />
    </>
  )
}
