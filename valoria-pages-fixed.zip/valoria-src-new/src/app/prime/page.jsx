import Nav from '@/components/Nav'
import Footer from '@/components/Footer'
import Reveal from '@/components/Reveal'
import { PRIME_CLUSTERS } from '@/lib/brand'
import '../pages.css'

export const metadata = {
  title: 'The PRIME Framework | Valoria Institute',
  description: 'Five capability clusters. One assessed standard. PRIME is the architecture behind the VALU Index and every Valoria Develop programme.',
}

const CLUSTER_DESCRIPTIONS = {
  P: 'How a professional shows up — composure, communication, and how clearly they carry their own expertise into a room.',
  R: 'How a professional works with others — collaboration, trust-building, and the quality of the relationships they sustain.',
  I: 'How a professional moves a decision — the ability to shift outcomes, not just contribute an opinion to them.',
  M: 'How a professional delivers — execution, accountability, resilience, and adaptability under pressure.',
  E: 'How a professional builds and operates — the structures, systems, and ventures they can stand up and run.',
}

const CLUSTER_SKILLS = {
  P: ['Communication', 'Negotiation', 'Personal Brand', 'Executive Presence', 'Business Acumen', 'Managing Ambiguity'],
  R: ['Emotional Intelligence', 'Conflict Resolution', 'People Development', 'Stakeholder Management'],
  I: ['Communication', 'Negotiation', 'Personal Brand & Executive Presence'],
  M: ['Execution & Accountability', 'Resilience & Self-Leadership', 'Adaptability'],
  E: ['Commercial Creativity', 'Influence Without Authority'],
}

export default function PrimePage() {
  return (
    <>
      <Nav />
      <main id="main-content">
        <section className="page-hero">
          <div className="page-hero-inner">
            <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">THE CAPABILITY ARCHITECTURE</span></div>
            <h1 className="page-title">Five clusters.<br /><em>One assessed standard.</em></h1>
            <p className="page-sub">
              PRIME is the framework underneath the VALU Index and every Valoria Develop programme. It defines what &ldquo;capable&rdquo; actually means across five dimensions — instead of leaving it to whoever&apos;s reading the résumé.
            </p>
          </div>
        </section>

        <section className="page-section">
          <div className="page-section-inner two-col">
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">WHY A FRAMEWORK</span></div>
              <h2 className="section-title">Capability without<br /><em>a standard is invisible.</em></h2>
              <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '15px' }}>
                Most organisations assess talent by intuition, CV, or interview performance. None of those measure the same thing consistently. PRIME gives every professional — and every organisation hiring, booking, or developing them — a shared language for what capability actually looks like.
              </p>
            </Reveal>
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">HOW IT WORKS</span></div>
              <h2 className="section-title">One assessment.<br /><em>Five dimensions.</em></h2>
              <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '15px' }}>
                The VALU Index scores every professional across all five PRIME clusters in 18 to 28 minutes. That score then powers three things: candidate search on ATB Connect, speaker discovery on ATB Spotlight, and programme design through Valoria Develop.
              </p>
            </Reveal>
          </div>
        </section>

        <section className="page-section alt">
          <div className="page-section-inner" style={{ maxWidth: '760px' }}>
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">THE FIVE CLUSTERS</span></div>
              <h2 className="section-title" style={{ marginBottom: '40px' }}>P · R · I · M · E</h2>
            </Reveal>
            <Reveal>
              {PRIME_CLUSTERS.map((c) => (
                <div className="cluster-row" key={c.letter} style={{ color: c.color }}>
                  <div className="cluster-letter">{c.letter}</div>
                  <div style={{ flex: 1 }}>
                    <div className="cluster-name" style={{ color: 'var(--parchment)' }}>{c.name}</div>
                    <p className="cluster-desc">{CLUSTER_DESCRIPTIONS[c.letter]}</p>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '12px' }}>
                      {CLUSTER_SKILLS[c.letter].map((skill) => (
                        <span key={skill} style={{
                          fontSize: '10px', fontWeight: 600, letterSpacing: '.12em',
                          padding: '4px 10px', borderRadius: '999px',
                          border: `1px solid ${c.color}44`,
                          color: c.color, background: `${c.color}11`
                        }}>{skill}</span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </Reveal>
          </div>
        </section>

        <section className="page-section">
          <div className="page-section-inner two-col">
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">PROPRIETARY & PROTECTED</span></div>
              <h2 className="section-title">Built for the<br /><em>African professional market.</em></h2>
              <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '15px' }}>
                PRIME was built specifically for how African professionals operate across industries, environments, and career stages. The methodology, cluster names, and scoring architecture are owned by Valoria Institute. The full assessment criteria are confidential.
              </p>
            </Reveal>
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">THREE WAYS PRIME WORKS FOR YOU</span></div>
              <ul className="checklist" role="list">
                {[
                  'Professionals — take the VALU Index to score yourself across all five clusters',
                  'Employers — search candidates filtered by cluster strength and tier designation',
                  'Training buyers — commission programmes that close the specific cluster gaps your team shows',
                ].map((t, i) => (
                  <li key={i}>
                    <span className="dot"><svg width="9" height="9" viewBox="0 0 9 9" fill="none"><path d="M1.5 4.5l2 2 4-4" stroke="var(--gold)" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" /></svg></span>
                    {t}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </section>

        <section className="page-section alt cta-banner">
          <Reveal>
            <div className="eyebrow" style={{ justifyContent: 'center' }}><div className="eyebrow-line" /><span className="eyebrow-text">SEE WHERE YOU SCORE</span><div className="eyebrow-line" /></div>
            <h2 className="section-title">Find out your<br /><em>own PRIME profile.</em></h2>
            <p className="page-sub">The VALU Index scores you across all five clusters in 18 to 28 minutes. Free, and valid for 12 months.</p>
            <a href="https://assessment.valoriainstitute.com/" className="btn-gold" target="_blank" rel="noopener noreferrer">BEGIN THE VALU INDEX — FREE</a>
          </Reveal>
        </section>
      </main>
      <Footer />
    </>
  )
}
