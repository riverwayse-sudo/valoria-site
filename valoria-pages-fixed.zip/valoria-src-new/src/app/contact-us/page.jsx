import Nav from '@/components/Nav'
import Footer from '@/components/Footer'
import Reveal from '@/components/Reveal'
import { BRAND } from '@/lib/brand'
import '../pages.css'

export const metadata = {
  title: 'Contact Valoria Institute',
  description: 'Get in touch with Valoria Institute — hiring enquiries, speaker bookings, training commissions, or VALU Index questions.',
}

export default function ContactPage() {
  return (
    <>
      <Nav />
      <main id="main-content">
        <section className="page-hero">
          <div className="page-hero-inner">
            <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">GET IN TOUCH</span></div>
            <h1 className="page-title">Let&apos;s talk<br /><em>capability.</em></h1>
            <p className="page-sub">
              Hiring, booking a speaker, commissioning a training programme, or just have a question about the VALU Index — reach us directly. No forms. No ticketing systems. Direct contact with the people who can help.
            </p>
          </div>
        </section>

        <section className="page-section">
          <div className="page-section-inner two-col">
            <Reveal>
              <div className="card-gold">
                <div className="eyebrow" style={{ marginBottom: '20px' }}><div className="eyebrow-line" /><span className="eyebrow-text">EMAIL</span></div>
                <a href={`mailto:${BRAND.email}`} style={{ color: 'var(--gold)', fontSize: '20px', textDecoration: 'none', fontWeight: 300, display: 'block', marginBottom: '12px' }}>{BRAND.email}</a>
                <p style={{ color: 'var(--dim)', fontWeight: 300, fontSize: '14px', lineHeight: 1.8 }}>We respond within two business days. For urgent programme enquiries, include your timeline in the subject line.</p>
              </div>
            </Reveal>
            <Reveal>
              <div className="card-gold">
                <div className="eyebrow" style={{ marginBottom: '20px' }}><div className="eyebrow-line" /><span className="eyebrow-text">LOCATION</span></div>
                <p style={{ color: 'var(--parchment)', fontSize: '20px', fontWeight: 300, marginBottom: '12px' }}>{BRAND.location}</p>
                <p style={{ color: 'var(--dim)', fontWeight: 300, fontSize: '14px', lineHeight: 1.8 }}>A {BRAND.copyrightEntity} initiative. Operating across West Africa and serving professionals globally. {BRAND.compliance}.</p>
              </div>
            </Reveal>
          </div>
        </section>

        <section className="page-section alt">
          <div className="page-section-inner">
            <Reveal>
              <div className="eyebrow" style={{ justifyContent: 'center' }}><div className="eyebrow-line" /><span className="eyebrow-text">CONTACT BY PURPOSE</span><div className="eyebrow-line" /></div>
              <h2 className="section-title" style={{ textAlign: 'center', marginBottom: '48px' }}>Go straight to<br /><em>the right conversation.</em></h2>
            </Reveal>
            <div className="three-col">
              {[
                { label: 'FOR EMPLOYERS', title: 'Hiring Enquiry', desc: 'Questions about ATB Connect, accessing assessed candidates, or setting up an employer account.', subject: 'Hiring%20Enquiry%20%E2%80%94%20ATB%20Connect' },
                { label: 'FOR EVENT ORGANISERS', title: 'Speaker Booking', desc: 'Looking to book a speaker from ATB Spotlight for your conference, event, or programme.', subject: 'Speaker%20Booking%20%E2%80%94%20ATB%20Spotlight' },
                { label: 'FOR TRAINING BUYERS', title: 'Training Enquiry', desc: 'Commissioning a PRIME-mapped programme through Valoria Develop for your team or cohort.', subject: 'Training%20Commission%20%E2%80%94%20Valoria%20Develop' },
              ].map((item) => (
                <Reveal key={item.label}>
                  <div className="card-gold" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                    <div className="eyebrow" style={{ marginBottom: '16px' }}><span className="eyebrow-text">{item.label}</span></div>
                    <h3 style={{ color: 'var(--parchment)', fontSize: '18px', fontWeight: 400, marginBottom: '12px' }}>{item.title}</h3>
                    <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '14px', flex: 1 }}>{item.desc}</p>
                    <a href={`mailto:${BRAND.email}?subject=${item.subject}`} className="btn-gold" style={{ marginTop: '24px', textAlign: 'center', display: 'block' }}>EMAIL US</a>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        <section className="page-section cta-banner">
          <Reveal>
            <div className="eyebrow" style={{ justifyContent: 'center' }}><div className="eyebrow-line" /><span className="eyebrow-text">NOT SURE WHERE TO START?</span><div className="eyebrow-line" /></div>
            <h2 className="section-title">Take the VALU Index<br /><em>and let the data decide.</em></h2>
            <p className="page-sub">The assessment is free, takes 18 to 28 minutes, and gives you a clear picture of where you stand across all five PRIME clusters.</p>
            <a href="https://assessment.valoriainstitute.com/" className="btn-gold" target="_blank" rel="noopener noreferrer">BEGIN THE VALU INDEX — FREE</a>
          </Reveal>
        </section>
      </main>
      <Footer />
    </>
  )
}
