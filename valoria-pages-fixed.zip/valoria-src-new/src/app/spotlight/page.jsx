import Nav from '@/components/Nav'
import Footer from '@/components/Footer'
import Reveal from '@/components/Reveal'
import { COLORS } from '@/lib/brand'
import '../pages.css'

export const metadata = {
  title: 'ATB Spotlight — Book Assessed Speakers',
  description: 'Discover and book speakers by expertise, tier designation, and VALU Index. Merit determines who gets on stage. Not network. Not seniority.',
}

const color = COLORS.gold

export default function SpotlightPage() {
  return (
    <>
      <Nav />
      <main id="main-content">
        <section className="page-hero">
          <div className="page-hero-inner">
            <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text" style={{ color }}>02 &nbsp;&middot;&nbsp; FOR EVENT ORGANISERS</span></div>
            <h1 className="page-title">Find the speaker<br /><em>nobody else booked yet.</em></h1>
            <p className="page-sub">
              ATB Spotlight is the speaker modality of the Valoria marketplace. Search by expertise, sector, and VALU Index score to find voices beyond the usual conference circuit — every one of them independently assessed.
            </p>
            <div className="page-hero-actions">
              <a href="https://assessment.valoriainstitute.com/" className="btn-gold" target="_blank" rel="noopener noreferrer">FIND A SPEAKER</a>
              <a href="/prime" className="btn-outline">SEE THE PRIME FRAMEWORK</a>
            </div>
          </div>
        </section>

        <section className="page-section">
          <div className="page-section-inner two-col">
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">THE CIRCUIT PROBLEM</span></div>
              <h2 className="section-title">Reputation got them<br />the stage. <em>Merit keeps them there.</em></h2>
              <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '15px' }}>
                Most speaker rosters are built on who organisers already know. Spotlight surfaces who can actually deliver — ranked by an assessed standard rather than name recognition alone, so your programme isn&apos;t the same five names every season.
              </p>
            </Reveal>
            <Reveal>
              <ul className="checklist" role="list">
                {[
                  'Filter by expertise, sector, tier designation, and VALU Index score',
                  'Every speaker independently assessed across all five PRIME clusters',
                  'Built for organisers who want range, not the same recycled lineup',
                  'Reach out directly once a profile fits your programme',
                ].map((t, i) => (
                  <li key={i}>
                    <span className="dot"><svg width="9" height="9" viewBox="0 0 9 9" fill="none"><path d="M1.5 4.5l2 2 4-4" stroke={color} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" /></svg></span>
                    {t}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </section>

        <section className="page-section alt">
          <div className="page-section-inner">
            <Reveal>
              <div className="eyebrow" style={{ justifyContent: 'center' }}><div className="eyebrow-line" /><span className="eyebrow-text">HOW ATB SPOTLIGHT WORKS</span><div className="eyebrow-line" /></div>
              <h2 className="section-title" style={{ textAlign: 'center', marginBottom: '48px' }}>From search to<br /><em>stage in three steps.</em></h2>
            </Reveal>
            <div className="three-col">
              {[
                { num: '01', title: 'Search by what your programme needs', body: 'Filter by topic, expertise cluster, sector, tier, and VALU Index score. Every speaker has been independently assessed — not self-described.' },
                { num: '02', title: 'Review the full profile', body: 'See the speaker\'s PRIME cluster breakdown, tier designation, speaking history, and areas of expertise — all in one place.' },
                { num: '03', title: 'Book directly', body: 'Contact the speaker directly through the platform. No agency markup. No intermediary. The stage they\'ve earned, the fee they\'ve negotiated.' },
              ].map((step) => (
                <Reveal key={step.num}>
                  <div className="card-gold">
                    <div style={{ fontSize: '32px', fontWeight: 200, color, marginBottom: '16px' }}>{step.num}</div>
                    <h3 style={{ color: 'var(--parchment)', fontSize: '16px', fontWeight: 500, marginBottom: '12px' }}>{step.title}</h3>
                    <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '14px' }}>{step.body}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        <section className="page-section">
          <div className="page-section-inner two-col">
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">FOR SPEAKERS</span></div>
              <h2 className="section-title">The stage you deserve —<br /><em>visible to the people who need to book it.</em></h2>
              <p style={{ color: 'var(--dim)', fontWeight: 300, lineHeight: 1.8, fontSize: '15px' }}>
                If you&apos;re a professional with speaking experience, take the VALU Index and get listed on ATB Spotlight. Merit determines who gets found. Not network. Not seniority.
              </p>
              <a href="https://assessment.valoriainstitute.com/" className="btn-gold" target="_blank" rel="noopener noreferrer" style={{ marginTop: '24px', display: 'inline-block' }}>GET LISTED AS A SPEAKER</a>
            </Reveal>
            <Reveal>
              <div className="eyebrow"><div className="eyebrow-line" /><span className="eyebrow-text">TIER REQUIREMENTS FOR SPEAKERS</span></div>
              <ul className="checklist" role="list">
                {[
                  'Emerging — min. 3 speaking credits, complete profile, 1 video sample, PRIME assessment done',
                  'Established — min. 10 credits, 2 public appearances, ATB-verified testimonials',
                  'Elite — min. 25 credits, national or international appearances, ATB panel review',
                ].map((t, i) => (
                  <li key={i}>
                    <span className="dot"><svg width="9" height="9" viewBox="0 0 9 9" fill="none"><path d="M1.5 4.5l2 2 4-4" stroke={color} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" /></svg></span>
                    {t}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </section>

        <section className="page-section alt cta-banner">
          <Reveal>
            <div className="eyebrow" style={{ justifyContent: 'center' }}><div className="eyebrow-line" /><span className="eyebrow-text">FOR EVENT ORGANISERS</span><div className="eyebrow-line" /></div>
            <h2 className="section-title">Build a lineup<br /><em>worth attending for.</em></h2>
            <p className="page-sub">ATB Spotlight is live. Create an organiser account to start browsing assessed speakers.</p>
            <a href="https://assessment.valoriainstitute.com/" className="btn-gold" target="_blank" rel="noopener noreferrer">FIND A SPEAKER</a>
          </Reveal>
        </section>
      </main>
      <Footer />
    </>
  )
}
